import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

fil_data=pd.read_csv("StandardSod_0_15.txt",sep=' ')
x_fil=np.array(fil_data['x'])
rho_fil=np.array(fil_data['rho'])
u_fil=np.array(fil_data['u'])
P_fil=np.array(fil_data['p'])
I_fil=np.array(fil_data['ie'])

def plo (x1,para1,x_ex,para_ex,title):
    plt.title(title)
    plt.xlabel("x (m) ")
    plt.ylabel(title)
    plt.scatter (x1,para1[:],5,"r",label="Stagger Warming")
    plt.plot(x_ex,para_ex[:],label="Analytical")    
    plt.legend()
    plt.show()
    
def flux (lam0,lam1,lam2,v,a_s,h,gama,rho):
        f=np.zeros(3)
        f[0] = (lam0+ 2*(gama - 1)*lam1 + lam2)*rho/(2*gama)
        f[1] = (lam0*(v-a_s) +2*(gama - 1)*v*lam1 + lam2*( v+ a_s ))*rho/(2*gama)
        f[2] = ((lam0)*(h-v*a_s) + (gama - 1)*v**2*lam1 + lam2*(h+v*a_s))*rho/(2*gama)
        return (f)

L=1
gam=1.4
n_cell=400
dx=L/n_cell
x=np.zeros(n_cell)
maxx=np.zeros(n_cell)
for i in range(1,n_cell):
    x[i]=x[i-1]+dx

CFL=0.8
Time=0.15
t=0
dt=0
W=[[1,0.125],[0,0],[1,0.1]]
U_ini=[[W[0][0],W[0][1]],[W[0][0]*W[1][0],W[0][1]*W[1][1]],[(0.5*W[0][0]*(W[1][0]**2))+(W[2][0]/(gam-1)),(0.5*W[0][1]*(W[1][1]**2))+(W[2][1]/(gam-1))]]
U=np.zeros((3,n_cell))
F=np.zeros((3,n_cell))
F_new=np.zeros((3,n_cell))
U_new=np.zeros((3,n_cell))
for i in range(3):
    for j in range(0,n_cell):    
        if (j<(n_cell/2)):
            U[i][j]=U_ini[i][0]
            U_new[i][j]=U_ini[i][0]
           
        else:
            U[i][j]=U_ini[i][1]
            U_new[i][j]=U_ini[i][1]
kk=0
while (t<Time):
    
    F_m=np.zeros((3,n_cell-1))
    F_p=np.zeros((3,n_cell-1))
    F_plus=np.zeros((3,n_cell))
    F_min=np.zeros((3,n_cell))
    maxx=np.zeros(n_cell)
    for i in range (n_cell):
        lamda=np.zeros(3)
        K=np.zeros((3,3))       
        vel=0
        a_snd=0
        H=0        
        vel=U[1][i]/U[0][i]
        a_snd=(((gam-1)*(U[2][i]-(0.5*(U[1][i]**2)/U[0][i])))*gam/U[0][i])**0.5
        H= (((gam-1)*(U[2][i]-(0.5* (U[1][i]**2)/ U[0][i]))) + U[2][i] )/ U[0][i]
        for j in range(-1,2,+1):          
            lamda[j+1]=vel+(j*a_snd)      
            K[j+1][0]=1                  
            K[j+1][1]=vel+(j*a_snd)
            K[j+1][2]=abs(j)*H+(j*vel*a_snd)
        maxx[i]=max(abs(lamda))

        
        F_plus[0][i],F_plus[1][i],F_plus[2][i]=flux(max(lamda[0],0),max(lamda[1],0),max(lamda[2],0),vel,a_snd,H,gam,U[0][i])
        F_min[:,i]=flux(min(lamda[0],0),min(lamda[1],0),min(lamda[2],0),vel,a_snd,H,gam,U[0][i])
    dt=CFL*dx/max(maxx)
    t=t+dt
    for i in range (1,n_cell-1):
        for j in range(3):
            F_m[j][i]=F_plus[j][i-1]+F_min[j][i]
            F_p[j][i]=F_plus[j][i]+F_min[j][i+1]
        for j in range(3):
            U_new[j][i]=U[j][i]-dt*(F_p[j][i]-F_m[j][i])/dx
    for i in range (n_cell):
        for j in range(3):
            U[j][i]=U_new[j][i]
P=np.zeros(n_cell)
Uv=np.zeros(n_cell)
I=np.zeros(n_cell)
for i in range (0,n_cell):
    P[i]=((gam-1)*(U[2][i]-(0.5*(U[1][i]**2)/U[0][i])))
    Uv[i]=U[1][i]/U[0][i]
    I[i]=(2*U[2][i]*U[0][i]-U[1][i]**2)/(2*U[0][i]**2)
plo(x,Uv,x_fil,u_fil,"Velocity")
plo(x,U[0,:],x_fil,rho_fil,"Density")
plo(x,P,x_fil,P_fil,"Pressure")
plo(x,I,x_fil,I_fil,"Internal Energy")


