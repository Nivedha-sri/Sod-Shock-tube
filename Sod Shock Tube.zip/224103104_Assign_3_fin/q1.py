import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
#----File Reading-------
fil_data=pd.read_csv("StandardSod_0_15.txt",sep=' ')
x_fil=np.array(fil_data['x'])
rho_fil=np.array(fil_data['rho'])
u_fil=np.array(fil_data['u'])
P_fil=np.array(fil_data['p'])
I_fil=np.array(fil_data['ie'])
W=np.zeros((3,3))
#-------Plotting---------
def plo (x1,para1,x_ex,para_ex,labe,title):
    plt.title(title)
    plt.xlabel("x (m) ")
    plt.ylabel(title)
    plt.scatter (x1,para1[:],5,"r",label=labe)
    plt.plot(x_ex,para_ex[:],label="Analytical")
    
    plt.legend()
    plt.show()
    
    

#-----Value Input-----
L=float(input("Enter the length"))
gam=1.4
n_cell=int(input("Enter the number of divsions"))
CFL=0.8
Time=float(input("Enter Simulation time"))
dx=L/n_cell

W[0][0]=float(input("Enter Left Density"))
W[0][1]=float(input("Enter Right Density"))
W[1][0]=float(input("Enter Left Velocity"))
W[1][1]=float(input("Enter Right Velocity"))
W[2][0]=float(input("Enter Left Pressure"))
W[2][1]=float(input("Enter Right Pressure"))
#W=[[1,0.125],[0,0],[1,0.1]]
U_ini=[[W[0][0],W[0][1]],[W[0][0]*W[1][0],W[0][1]*W[1][1]],[(0.5*W[0][0]*(W[1][0]**2))+(W[2][0]/(gam-1)),(0.5*W[0][1]*(W[1][1]**2))+(W[2][1]/(gam-1))]]
#----Variable Inisialisation-----
x=np.zeros(n_cell+1)
U=np.zeros((3,n_cell+1))
U_next=np.zeros((3,n_cell+1))
t=0
dt=0
#---Cell definintion-----------
for i in range(1,n_cell+1):
    x[i]=x[i-1]+dx
#----U initialisation---------
for i in range(3):
    for j in range(0,n_cell+1):    
        if (j<(n_cell/2)):
            U[i][j]=U_ini[i][0]
            
        else:
            U[i][j]=U_ini[i][1]

e=10**-6
cntr=0
#-----Loop for time advancement-----
while(t<=Time):
    #------Initialisation------
    F=np.zeros((3,n_cell+1))
    F_new=np.zeros((3,n_cell+1))
    H=np.zeros(n_cell+1)
    maxx=np.zeros(n_cell)
    delt=np.zeros(3)
    u_til=H_til=a_til=0
    #-----H value updation---    
    for i in range(n_cell-1):          
        H[i]=( ((gam-1)*(U[2][i]-(0.5*(U[1][i]**2)/U[0][i]))) + U[2][i] )/ U[0][i]
       
                
    #-----Loop for cell advancement----   
    for i in range(n_cell-1):
        #------Initialisation------
        lamda=np.zeros(3)
        K=np.zeros((3,3))
        #------Tilda Value---------
        u_til=(((U[0][i+1]**0.5)*U[1][i+1]/U[0][i+1])+((U[0][i]**0.5)*U[1][i]/U[0][i]))/(U[0][i]**0.5+U[0][i+1]**0.5)        
        H_til=(((U[0][i+1]**0.5)*H[i+1])+((U[0][i]**0.5)*H[i]))/(U[0][i+1]**0.5+U[0][i]**0.5)        
        a_til=((gam-1)*(H_til-((u_til**2)/2)))**0.5
        #------Delta Values--------        
        delt[1]=(((U[0][i+1]-U[0][i])*(H_til-(u_til**2)))+(u_til*(U[1][i+1]-U[1][i]))-(U[2][i+1]-U[2][i]))*(gam-1)/(a_til**2)        
        delt[0]=(((U[0][i+1]-U[0][i])*(u_til+a_til))-(U[1][i+1]-U[1][i])-(a_til*delt[1]))/(2*a_til)
        delt[2]=((U[0][i+1]-U[0][i])-delt[0]-delt[1])
        #-----Eigen Values and Eigen Vectors---         
        for j in range(-1,2,+1):
            lamda[j+1]=u_til+(j*a_til)
            K[j+1][0]=1                  
            K[j+1][1]=u_til+(j*a_til)
            K[j+1][2]=H_til+(j*u_til*a_til)
            if (abs(lamda[j+1])<e):
                lamda[j+1]=(lamda[j+1]**2/e + e)*0.5
                if(71<cntr<60):
                    print(lamda[j+1],i)
                cntr=cntr+1

            else :
                lamda[j+1]=lamda[j+1]
                
        maxx[i]=max(abs(lamda))             
        K[1][2]=(u_til**2)/2
        #------Flux Values using U values-----      
        F[0][i]=U[1][i]
        F[1][i]=((3 - gam)*0.5*(U[1][i]**2)/U[0][i]) + (gam-1)*U[2][i]        
        F[2][i]=(gam * U[1][i] * U[2][i] / U[0][i]) - ((gam - 1) *0.5* (U[1][i] ** 3) / (U[0][i] ** 2))    
        #-----Flux Values at Interface--------   
        for l in range(3):
            su=0                            
            for m in range(3):
                if(lamda[m]<0):
                    su=su+lamda[m]*delt[m]*K[m][l] #Sum is added to Flux calculated using U
                else:
                    su=su+0                
            F_new[l][i+1]=F[l][i]+su #F(i+1/2)
            
    #------dt using CFL condition-------  
    dt=CFL*dx/max(maxx)
    t=t+dt
    #------FDM for U updation----------
    for j in range(1,n_cell-1):        
            for i in range(3):                
                U_next[i][j]=U[i][j]-(dt*(F_new[i][j+1]-F_new[i][j])/dx)
                U[i][j]=U_next[i][j] # Transferring Values


"""for j in range (0,n_cell):
            if (j>390):                
                for i in range (3):
            
                    print(U[i][j],end=" ")
                print("\n")
                    #print(F_new[i][j+1],F_new[i][j],end="\t")"""
"""        
for j in range (0,n_cell):
    for i in range (3):            
        print(U[i][j],end=" ")
    print(j,"\n")"""
P=np.zeros(n_cell+1)
Uv=np.zeros(n_cell+1)
I=np.zeros(n_cell+1)
for i in range (0,n_cell+1):
    P[i]=((gam-1)*(U[2][i]-(0.5*(U[1][i]**2)/U[0][i])))
    Uv[i]=U[1][i]/U[0][i]
    I[i]=(2*U[2][i]*U[0][i]-U[1][i]**2)/(2*U[0][i]**2)
"""plo(x,Uv,x_fil,u_fil,"Rhoe's","Velocity")
plo(x,U[0,:],x_fil,rho_fil,"Rhoe's","Density")
plo(x,P,x_fil,P_fil,"Rhoe's","Pressure")
plo(x,I,x_fil,I_fil,"Rhoe's","Internal Energy")"""
plo(x,Uv,x_fil,u_fil,"Rhoe's Entropy fix","Velocity")
plo(x,U[0,:],x_fil,rho_fil,"Rhoe's Entropy fix","Density")
plo(x,P,x_fil,P_fil,"Rhoe's Entropy fix","Pressure")
plo(x,I,x_fil,I_fil,"Rhoe's Entropy fix","Internal Energy")
     
        
        
        
    
               
        
        
    





    


    


    
